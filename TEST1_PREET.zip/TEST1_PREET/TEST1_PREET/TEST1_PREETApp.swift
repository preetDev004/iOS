//
//  TEST1_PREETApp.swift
//  TEST1_PREET
//
//  Created by Preet Patel on 17/10/24.
//

import SwiftUI

@main
struct TEST1_PREETApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
